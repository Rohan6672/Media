package mediaRentalManager;

public class Album extends  Media{
	int numOfRec;
	String title;
	String artist;
	String songs;
	@Override
	public void setNumOfRec(int numOfRec) {
		this.numOfRec = numOfRec;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getSongs() {
		return songs;
	}

	public void setSongs(String songs) {
		this.songs = songs;
	}

	public Album(String title, int numOfRec, String artist, String songs) {
		this.title= title;
		this.artist= artist;
		this.songs=songs; 
		this.numOfRec= numOfRec;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return title;
	}

	@Override
	public int numOfRec() {
		// TODO Auto-generated method stub
		return numOfRec;
	}
	

	@Override
	public int compareTo(Media o) {
		return this.getTitle().compareTo(o.getTitle());
	}

	@Override
	public String toString() {
		return "Title: " + title + ", Copies Available: " + numOfRec + ", Artist: " + artist+", Songs: "+songs+"\n";
	}

	
	
	

}
