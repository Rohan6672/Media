package mediaRentalManager;

import java.util.ArrayList;

public class Customer implements Comparable<Customer>{
	String name;
	String address;
	String plan;
	ArrayList<Media> want;
	ArrayList<Media>has;
	
	
	
	public Customer(String name, String address, String plan, ArrayList<Media> want, ArrayList<Media> has) {
		super();
		this.name = name;
		this.address = address;
		this.plan = plan;
		this.want = want;
		this.has = has;
	}


	public Customer(String name, String address, String plan) {
		super();
		this.name = name;
		this.address = address;
		this.plan = plan;
		this.want=new  ArrayList<Media>();
		this.has= new ArrayList<Media> ();
				
		
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPlan() {
		return plan;
	}


	public void setPlan(String plan) {
		this.plan = plan;
	}


	public ArrayList<Media> getWant() {
		return want;
	}


	public void setWant(ArrayList<Media> want) {
		this.want = want;
	}


	public ArrayList<Media> getHas() {
		return has;
	}


	public void setHas(ArrayList<Media> has) {
		this.has = has;
	}
	public String getTitle2(ArrayList<Media>mediaList) {
		String ans="[";
		for(int i=0;i<mediaList.size();i++) {
			Media curr = mediaList.get(i);
			if(i==mediaList.size()-1) {
				ans+=curr.getTitle();
			}
			else {
				ans+=curr.getTitle()+", ";
			}
			
		}
		return ans+"]";
	}
	

	@Override
	public String toString() {
		return "Name: " + name + ", Address: " + address + ", Plan: " + plan+"\nRented: " + getTitle2(has) + "\nQueue: " + getTitle2(want)+"\n";
				
	}


	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public boolean addQueue(Media media) {
		for(int i=0;i<want.size();i++) {
			if(want.get(i).getTitle().equals(media.getTitle())) {
				return false;
			}
			
		}
		want.add(media);
		return true;
		
	}
	public boolean remQueue(Media media) {
		for(int i=0;i<want.size();i++) {
			if(want.get(i).getTitle().equals(media.getTitle())) {
				want.remove(media);
				return true;
			}
			
		}
		
		return false;
		
	}
	
	public boolean returnMed(Media media ) {
		this.has.remove(media);
		media.setNumOfRec(media.numOfRec()+1);
		return true;
	}
	public String rent (Media media) {
		this.has.add(media);
		this.want.remove(media);
		media.setNumOfRec(media.numOfRec()-1);
		return "Sending "+ media.getTitle()+" to "+this.getName()+"\n"; 
		
		
	}

	
	@Override
	public int compareTo(Customer o) {
		return this.getName().compareTo(o.getName());
		
	}

}
