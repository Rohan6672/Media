package mediaRentalManager;

public abstract class Media implements Comparable<Media> {
	public abstract String getTitle();
	public abstract int numOfRec();
	public abstract void setNumOfRec(int numOfRec);
	public abstract String toString();
	
}





