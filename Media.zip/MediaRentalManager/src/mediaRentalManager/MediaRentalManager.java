package mediaRentalManager;

import java.util.ArrayList;
import java.util.Collections;

public class MediaRentalManager  implements MediaRentalManagerInt {
	int planLimit=0;
	ArrayList <Customer> customers= new ArrayList<Customer>(); 
	ArrayList <Media> media= new ArrayList<Media>(); 
	public MediaRentalManager() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addCustomer(String name, String address, String plan) {
		Customer customer =new Customer(name,address,plan);
		customers.add(customer);
	}

	@Override
	public void addMovie(String title, int copiesAvailable, String rating) {
		Movie movie = new Movie(title, copiesAvailable, rating );
		media.add(movie);
	}

	@Override
	public void addAlbum(String title, int copiesAvailable, String artist, String songs) {
		Album album = new Album(title,copiesAvailable, artist,songs);
		media.add(album);
		
	}

	@Override
	public void setLimitedPlanLimit(int value) {
		planLimit=value;
		
	}

	@Override
	public String getAllCustomersInfo() {
		String m ="***** Customers' Information *****\n";
		Collections.sort(customers);
		for(int i=0;i<customers.size();i++) {
			m = m+ customers.get(i).toString();
			
			
		}
		//System.out.println(m);
		return m;
		
	}

	@Override
	public String getAllMediaInfo() {
		String m ="***** Media Information *****\n";
		Collections.sort(media);
		for(int i=0;i<media.size();i++) {
			m = m+media.get(i).toString();
			
			
		}
		//System.out.println(m);
		return m;
	}
	public Customer getCusNam(String customerNam) {
		for(int i =0;i<customers.size();i++) {
			if(customers.get(i).getName().equals(customerNam)) {
				return customers.get(i);
			}
		}
		return null;
		
	}
	public Media getMedNam(String MedNam) {
		for(int i =0;i<media.size();i++) {
			if(media.get(i).getTitle().equals(MedNam)) {
				return media.get(i);
			}
		}
		return null;
		
	}
	

	@Override
	public boolean addToQueue(String customerName, String mediaTitle) {
		Customer cus= getCusNam(customerName);
		Media media= getMedNam(mediaTitle);
		return cus.addQueue(media);
		
	}
	

	@Override
	public boolean removeFromQueue(String customerName, String mediaTitle) {
		Customer cus= getCusNam(customerName);
		Media media= getMedNam(mediaTitle);
		return cus.remQueue(media);
	}
	
	

	@Override
	public String processRequests() {
		String ans="";
		Collections.sort(customers);
		for(int i =0;i<customers.size();i++) {
			Customer current= customers.get(i);
			
			
			
			for(int x=0;x<current.getWant().size();x++) {
				Media curWant=current.getWant().get(x);
				
				if(curWant.numOfRec()>0) {
					if(current.getPlan().equals("UNLIMITED")) {
						
						
						ans	+=current.rent(curWant);
						x--;
					}
					else {
						if(current.has.size()<2) {
							
							x--;
							ans	+=current.rent(curWant);
						}
					}
				}
			}
			
			
			
		}
		return ans;
		
	}

	@Override
	public boolean returnMedia(String customerName, String mediaTitle) {
		Customer cus= getCusNam(customerName);
		Media media= getMedNam(mediaTitle);
		cus.returnMed(media);
		return true;
	}

	@Override
	public ArrayList<String> searchMedia(String title, String rating, String artist, String songs) {
		ArrayList<String> titles = new ArrayList();
		
		for(int i=0;i<media.size();i++) {
			boolean ifAdd=false;
			Media current = media.get(i);
			if(title!=null&&current.getTitle().equals(title)) {
				ifAdd=true;
			}
			if(current instanceof Movie) {
				Movie movie=(Movie)current;
			
				if(rating!=null&&movie.getRating().equals(rating)) {
					ifAdd=true;
				}
			}
			else {
				Album al=(Album)current;
				if(artist!=null&&al.getArtist().equals(artist)) {
					ifAdd=true;
				}
				System.out.println(al.getSongs());
				if(songs!=null&&al.getSongs().contains(songs)) {
					ifAdd=true;
				}
				
			}
			if(ifAdd==true) {
				titles.add(current.getTitle());
			}
		}
		
		 Collections.sort(titles);
		 return titles;
		 
	}

}
