package mediaRentalManager;

public class Movie extends Media{
	String title;
	int numOfRec;
	String rating;
	public Movie(String title, int numOfRec, String rating) {
		this.title= title;
		this.numOfRec= numOfRec;
		this.rating = rating;
	}

	
	public String getTitle() {
		// TODO Auto-generated method stub
		return title;
	}

	@Override
	public int numOfRec() {
		// TODO Auto-generated method stub
		return numOfRec;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public void setNumOfRec(int numOfRec) {
		this.numOfRec = numOfRec;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public int compareTo(Media o) {
		
		return this.getTitle().compareTo(o.getTitle());
	}

	@Override
	public String toString() {
		return "Title: " + title + ", Copies Available: " + numOfRec + ", Rating: " + rating+"\n";
	}

	
	
}
